SELVABHARATHI R - RESPONSIVE PORTFOLIO

Files:
- index.html : portfolio page content
- style.css  : colours, layout, and responsive styling

HOW TO VIEW:
1. Extract the ZIP file.
2. Open the folder.
3. Double-click index.html. It will open in your web browser.

HOW TO EDIT:
- Open index.html in Notepad or Visual Studio Code to change text.
- Open style.css to change colours, spacing, and design.

BEFORE SUBMISSION:
- No phone number or personal contact details are displayed on the portfolio.
- Add any real project details you want to showcase.
- Publish the website using a hosting service (for example, GitHub Pages) and submit that public URL in Edbytes.
- Take screenshots of the page at desktop and mobile widths.
